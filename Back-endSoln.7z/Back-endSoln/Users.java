package com.user.album;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

import org.json.JSONArray;
import org.json.JSONObject;


public class Users {
public static void main(String[] args) throws Exception {

names();
Albumnames();
}

public static String names() throws Exception {

String sb_temp = new String();

        JSONArray jsonArray=new JSONArray(readUrl("https://jsonplaceholder.typicode.com/users")); 

        String[] names = new String[jsonArray.length()];
         for(int i=0;i<jsonArray.length();i++){

            JSONObject obj=jsonArray.getJSONObject(i); 
            sb_temp = obj.getString("name"); 
            
            System.out.println(sb_temp);
            names[i] = sb_temp;
         }
         
         return sb_temp;
}


public static void Albumnames() throws Exception {

String sb_temp1 = new String();
String sb_temp2 = new String();
String albumTitle = new String();

JSONArray jsonArray =new JSONArray(readUrl("https://jsonplaceholder.typicode.com/users"));
        JSONArray jsonArray1 = new JSONArray(readUrl("https://jsonplaceholder.typicode.com/albums")); 

        String[] albumId = new String[jsonArray1.length()];
        String[] Title = new String[jsonArray1.length()];
        String[] users = new String[jsonArray.length()];
         for(int i=0;i<jsonArray.length();i++){
        
        JSONObject obj=jsonArray.getJSONObject(i);
        int id =obj.getInt("id");
        
        sb_temp1 =Integer.toString(id);
        users[i] = sb_temp1;
           
            
         }
         
         for(int j =0;j<jsonArray1.length();j++)
         {
         	JSONObject obj1=jsonArray1.getJSONObject(j);
         	int userId =obj1.getInt("userId");
       	 
         	sb_temp2 = Integer.toString(userId);
         	albumTitle = obj1.getString("title");
         	
         	albumId[j] = sb_temp2;
         	Title[j] = albumTitle;
         	
         }
         
         for(int i=0;i<users.length;i++)
         {
        for(int j=0;j<albumId.length;j++)
        {
        if(users[i] == albumId[j])
        {
        System.out.println("Id matches ");
        System.out.println(Title[j].toString());
        
        }
        }
         }
        
         
}

public static String readUrl(String url) throws Exception {
        URL website = new URL(url);
        URLConnection connection = website.openConnection();
        BufferedReader in = new BufferedReader( new InputStreamReader(connection.getInputStream(),"UTF8"));

        StringBuilder response = new StringBuilder();
        String inputLine;

        while ((inputLine = in.readLine()) != null) 
            response.append(inputLine);

        in.close();

        return response.toString();
    }



}

